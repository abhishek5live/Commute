package com.abhishek.unifiedinbox

import java.util.Locale
import kotlin.math.abs

data class DuplicatePair(val first: Message, val second: Message)

object DuplicateDetector {
    private fun norm(s: String): String = s.trim().lowercase(Locale.getDefault()).replace(Regex("\\s+"), " ")

    /**
     * Finds likely cross-account duplicates: same sender/group + same message text,
     * arriving through WhatsApp Personal and WhatsApp Business within a short window.
     * The user must explicitly approve a merge; nothing is deleted automatically.
     */
    fun find(messages: List<Message>, windowMs: Long = 2 * 60 * 1000L): List<DuplicatePair> {
        val wa = messages.filter { it.source == "WhatsApp" || it.source == "WhatsApp Business" }
            .sortedBy { it.time }
        val result = mutableListOf<DuplicatePair>()
        for (i in wa.indices) {
            val a = wa[i]
            for (j in i + 1 until wa.size) {
                val b = wa[j]
                if (b.time - a.time > windowMs) break
                if (a.source == b.source) continue
                if (norm(a.sender) == norm(b.sender) && norm(a.body) == norm(b.body)) {
                    result += DuplicatePair(a, b)
                }
            }
        }
        return result
    }
}
