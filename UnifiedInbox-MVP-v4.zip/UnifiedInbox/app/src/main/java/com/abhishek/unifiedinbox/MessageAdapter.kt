package com.abhishek.unifiedinbox

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(private var items: List<Message>, private val onReply: (Message) -> Unit, private val onTask: (Message) -> Unit, private val onCalendar: (Message) -> Unit) : RecyclerView.Adapter<MessageAdapter.VH>() {
    private val fmt = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    fun setItems(v: List<Message>) { items = v; notifyDataSetChanged() }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(LayoutInflater.from(p.context).inflate(R.layout.item_message, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) { val m=items[i]; h.source.text=m.source; h.sender.text=m.sender; h.body.text=m.body; h.time.text=fmt.format(Date(m.time)); h.reply.visibility=if(m.replyAction!=null) View.VISIBLE else View.GONE; h.reply.setOnClickListener{onReply(m)}; h.task.setOnClickListener{onTask(m)}; h.calendar.setOnClickListener{onCalendar(m)} }
    class VH(v: View): RecyclerView.ViewHolder(v) { val source=v.findViewById<TextView>(R.id.source); val sender=v.findViewById<TextView>(R.id.sender); val body=v.findViewById<TextView>(R.id.body); val time=v.findViewById<TextView>(R.id.time); val reply=v.findViewById<Button>(R.id.reply); val task=v.findViewById<Button>(R.id.task); val calendar=v.findViewById<Button>(R.id.calendar) }
}
