package com.abhishek.unifiedinbox

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object TaskStore {
    private const val PREF = "tasks"
    private const val KEY = "items"
    fun add(context: Context, task: Task) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(p.getString(KEY, "[]"))
        arr.put(JSONObject().apply { put("id", task.id); put("messageId", task.messageId); put("title", task.title); put("dueAt", task.dueAt); put("source", task.source); put("sender", task.sender); put("body", task.body); put("completed", task.completed) })
        p.edit().putString(KEY, arr.toString()).apply()
    }
    fun all(context: Context): List<Task> {
        val arr = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
        return (arr.length()-1 downTo 0).map { i -> arr.getJSONObject(i).let { Task(it.getLong("id"), it.getLong("messageId"), it.getString("title"), it.getLong("dueAt"), it.getString("source"), it.getString("sender"), it.getString("body"), it.optBoolean("completed", false)) } }
    }
    fun complete(context: Context, id: Long) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE); val arr = JSONArray(p.getString(KEY, "[]"))
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getLong("id") == id) arr.getJSONObject(i).put("completed", true)
        p.edit().putString(KEY, arr.toString()).apply()
    }
}
