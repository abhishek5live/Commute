package com.abhishek.unifiedinbox

data class Message(val id: Long, val source: String, val sender: String, val body: String, val time: Long, val replyAction: android.app.PendingIntent? = null)
