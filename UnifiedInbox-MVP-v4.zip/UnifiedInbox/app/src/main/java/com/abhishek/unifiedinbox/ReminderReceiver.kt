package com.abhishek.unifiedinbox

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Task reminder"
        val body = intent.getStringExtra("body") ?: "You have a task due."
        val channelId = "task_reminders"
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "Task reminders", NotificationManager.IMPORTANCE_HIGH))
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(body)
            .setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(intent.getLongExtra("id", System.currentTimeMillis()).toInt(), notification) } catch (_: SecurityException) { }
    }
}
