package com.abhishek.unifiedinbox

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: MessageAdapter
    private var filter = "All"
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        val list=findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.list)
        adapter=MessageAdapter(emptyList(), { reply(it) }, { createTodo(it) }, { addCalendar(it) })
        list.layoutManager=LinearLayoutManager(this); list.adapter=adapter
        findViewById<Button>(R.id.accessButton).setOnClickListener{startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))}
        val clearSwitch=findViewById<Switch>(R.id.autoClearSwitch)
        val prefs=getSharedPreferences("settings", MODE_PRIVATE)
        clearSwitch.isChecked=prefs.getBoolean("auto_clear_notifications", true)
        clearSwitch.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("auto_clear_notifications", checked).apply() }
        findViewById<Button>(R.id.duplicatesBtn).setOnClickListener{showDuplicates()};
        findViewById<Button>(R.id.allBtn).setOnClickListener{filter="All";refresh()}; findViewById<Button>(R.id.waBtn).setOnClickListener{filter="WhatsApp";refresh()}; findViewById<Button>(R.id.smsBtn).setOnClickListener{filter="SMS";refresh()}; findViewById<Button>(R.id.workBtn).setOnClickListener{filter="Work";refresh()}
        refresh()
        requestNotificationsPermission()
    }
    override fun onResume(){super.onResume(); refresh()}
    private fun refresh(){ val all=MessageStore.all(this); val shown=when(filter){"WhatsApp"->all.filter{it.source.startsWith("WhatsApp")};"SMS"->all.filter{it.source=="SMS"};"Work"->all.filter{it.body.contains(Regex("loan|bank|document|customer|sir|branch|payment|account|emi|credit",RegexOption.IGNORE_CASE))};else->all}; adapter.setItems(shown) }
    private fun reply(m: Message){
        val pi=m.replyAction ?: return; val input=EditText(this); input.hint="Type your reply"
        AlertDialog.Builder(this).setTitle("Reply to ${m.sender}").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Send"){_,_->
            Toast.makeText(this,"Reply action is available from the WhatsApp notification. Full RemoteInput delivery will be enabled in the next integration step.",Toast.LENGTH_LONG).show()
        }.show()
    }
    private fun createTodo(m: Message){
        val input=EditText(this); input.setText(suggestTask(m)); input.hint="What needs to be done?"
        val cal=Calendar.getInstance().apply{add(Calendar.HOUR_OF_DAY,1); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)}
        AlertDialog.Builder(this).setTitle("Create To-Do from message").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Choose date & time"){_,_->
            }.show()
    }
    private fun saveTodo(m: Message,title:String,dueAt:Long){
        if(title.isBlank()) return
        val id=System.currentTimeMillis(); val task=Task(id,m.id,title,dueAt,m.source,m.sender,m.body)
        TaskStore.add(this,task); scheduleReminder(task)
        Toast.makeText(this,"To-Do saved for ${SimpleDateFormat("dd MMM, HH:mm",Locale.getDefault()).format(Date(dueAt))}",Toast.LENGTH_LONG).show()
    }
    private fun scheduleReminder(task: Task){
        val alarm=getSystemService(ALARM_SERVICE) as AlarmManager
        val pi=PendingIntent.getBroadcast(this,task.id.toInt(),Intent(this,ReminderReceiver::class.java).apply{putExtra("id",task.id);putExtra("title",task.title);putExtra("body","${task.sender}: ${task.body}")},PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if(android.os.Build.VERSION.SDK_INT>=31 && !alarm.canScheduleExactAlarms()) { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); return }
        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,task.dueAt,pi)
    }
    private fun addCalendar(m: Message){
        val cal=Calendar.getInstance().apply{add(Calendar.HOUR_OF_DAY,1); set(Calendar.MINUTE,0); set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        val intent=Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE,suggestTask(m)).putExtra(CalendarContract.Events.DESCRIPTION,"From ${m.source} • ${m.sender}\n\n${m.body}").putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,cal.timeInMillis).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,cal.timeInMillis+30*60*1000)
        try{startActivity(intent)}catch(_:Exception){Toast.makeText(this,"No calendar app found",Toast.LENGTH_SHORT).show()}
    }
    private fun suggestTask(m:Message)=when{m.body.contains(Regex("call|फोन|call me",RegexOption.IGNORE_CASE))->"Call ${m.sender}";m.body.contains(Regex("document|docs|document भेज",RegexOption.IGNORE_CASE))->"Follow up on documents from ${m.sender}";m.body.contains(Regex("payment|pay|भुगतान",RegexOption.IGNORE_CASE))->"Follow up on payment with ${m.sender}";else->"Follow up with ${m.sender}"}

    private fun showDuplicates(){
        val pairs = DuplicateDetector.find(MessageStore.all(this))
        if (pairs.isEmpty()) {
            Toast.makeText(this, "No likely WhatsApp duplicates found", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = pairs.map { "${it.first.sender}: ${it.first.body}\n${it.first.source} ↔ ${it.second.source}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Possible duplicate messages (${pairs.size})")
            .setItems(labels) { _, which -> showMergeDialog(pairs[which]) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showMergeDialog(pair: DuplicatePair){
        AlertDialog.Builder(this)
            .setTitle("Merge duplicate?")
            .setMessage("Same sender/group and same message were received from both WhatsApp Personal and WhatsApp Business.\n\n${pair.first.body}\n\nMerge them into one message?")
            .setNegativeButton("Keep both", null)
            .setPositiveButton("Merge") { _, _ ->
                MessageStore.merge(this, pair.first.id, pair.second.id)
                refresh()
                Toast.makeText(this, "Merged into one message", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun requestNotificationsPermission(){if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),42)}
}
