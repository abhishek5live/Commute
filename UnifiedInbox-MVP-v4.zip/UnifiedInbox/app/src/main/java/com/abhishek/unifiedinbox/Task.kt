package com.abhishek.unifiedinbox

data class Task(val id: Long, val messageId: Long, val title: String, val dueAt: Long, val source: String, val sender: String, val body: String, val completed: Boolean = false)
