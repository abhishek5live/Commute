package com.abhishek.unifiedinbox

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils

class MessageNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = sbn.packageName
        val isWhatsApp = p == "com.whatsapp" || p == "com.whatsapp.w4b" || p.contains("whatsapp", true)
        val isSms = p.contains("messaging", true) || p.contains("mms", true) || p.contains("sms", true)
        if (!isWhatsApp && !isSms) return
        val n = sbn.notification
        val extras = n.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: "Unknown"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: return
        if (TextUtils.isEmpty(text)) return
        val source = when { isWhatsApp && p == "com.whatsapp.w4b" -> "WhatsApp Business"; isWhatsApp -> "WhatsApp"; else -> "SMS" }
        val reply = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }?.actionIntent
        MessageStore.add(this, Message(sbn.id.toLong() shl 32 or (sbn.postTime and 0xffffffffL), source, title, text, sbn.postTime, reply))
        // The app has received the message; optionally remove the original WhatsApp/SMS notification.
        // NotificationListenerService is allowed to cancel notifications posted by observed apps.
        if (getSharedPreferences("settings", MODE_PRIVATE).getBoolean("auto_clear_notifications", true)) {
            runCatching { cancelNotification(sbn.key) }
        }
        sendBroadcast(android.content.Intent("com.abhishek.unifiedinbox.NEW_MESSAGE"))
    }
}
