package com.abhishek.unifiedinbox

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object MessageStore {
    private const val PREF = "messages"
    private const val KEY = "items"
    fun add(context: Context, message: Message) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(p.getString(KEY, "[]"))
        val o = JSONObject().apply { put("id", message.id); put("source", message.source); put("sender", message.sender); put("body", message.body); put("time", message.time) }
        arr.put(o)
        while (arr.length() > 300) arr.remove(0)
        p.edit().putString(KEY, arr.toString()).apply()
    }
    fun all(context: Context): List<Message> {
        val arr = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
        return (arr.length()-1 downTo 0).map { i -> arr.getJSONObject(i).let { Message(it.getLong("id"), it.getString("source"), it.getString("sender"), it.getString("body"), it.getLong("time")) } }
    }

    fun merge(context: Context, firstId: Long, secondId: Long): Message? {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(p.getString(KEY, "[]"))
        var first: JSONObject? = null
        var second: JSONObject? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            when (o.getLong("id")) {
                firstId -> first = o
                secondId -> second = o
            }
        }
        if (first == null || second == null) return null
        val f = first!!
        f.put("source", "WhatsApp (Personal + Business)")
        // Keep the earlier message id/time and remove the duplicate entry.
        for (i in arr.length() - 1 downTo 0) {
            val id = arr.getJSONObject(i).getLong("id")
            if (id == secondId) arr.remove(i)
        }
        for (i in 0 until arr.length()) {
            if (arr.getJSONObject(i).getLong("id") == firstId) {
                arr.put(i, f)
                break
            }
        }
        p.edit().putString(KEY, arr.toString()).apply()
        return Message(firstId, f.getString("source"), f.getString("sender"), f.getString("body"), f.getLong("time"))
    }
}
