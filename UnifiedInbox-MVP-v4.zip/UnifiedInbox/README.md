# Unified Inbox — Android MVP

A consent-based Android unified inbox for WhatsApp/WhatsApp Business/SMS notifications.

## What this version does
- Requests Android Notification Access explicitly.
- Captures WhatsApp, WhatsApp Business and common SMS/messaging notifications.
- Stores up to 300 captured messages locally.
- Filters All / WhatsApp / SMS / Work.
- Detects notifications exposing Android RemoteInput reply actions.

## Important platform limits
- Notification access does not expose the complete historical WhatsApp database.
- Only notification content supplied by Android is available.
- Reply is only possible when the source notification exposes a supported RemoteInput action; the final production implementation should invoke that action with Android's RemoteInput APIs rather than attempting to bypass WhatsApp.
- Dual WhatsApp installations vary by device/OEM. Some phones use the same package with account-specific notification channels; others use a cloned package. The production build should identify the account from notification extras/channel/profile where available.
- For Google Play distribution, Notification Listener access and SMS-related functionality must comply with current Play policies and disclosures.

## Build
Open in Android Studio and build the debug APK. The chat workspace used to generate this project does not include the Android SDK/Gradle build environment, so an APK could not be compiled here.

## Message actions: To-Do + Calendar
Each message now has **To-Do** and **Calendar** actions. To-Do lets the user edit a task title, choose a date/time, stores the task locally, and schedules a device reminder. Calendar opens the user's calendar app with the message context pre-filled. The message sender/body are retained as the task's source context.


## Notification auto-clear
When Notification Access is enabled, the listener imports WhatsApp Personal (`com.whatsapp`), WhatsApp Business (`com.whatsapp.w4b`) and messaging notifications. If **Remove original WhatsApp/SMS notification after import** is enabled, the listener calls `cancelNotification(sbn.key)` after successfully importing the notification. This removes the original notification from the notification shade. The setting is user-controlled and can be disabled.

## Cross-WhatsApp duplicate detection
The app now detects likely duplicate notifications received through WhatsApp Personal and WhatsApp Business when sender/group and message text match within a short time window. Detection is conservative and **does not delete anything automatically**. Use **Duplicates** to review candidates and explicitly choose **Merge** or **Keep both**. A merged message is labeled `WhatsApp (Personal + Business)`.
